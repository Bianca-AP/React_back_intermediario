import React from 'react';




function Home(){
    return(
     
    <div>
        <title>Full Stack Eletro</title>
        <div className="container-fluid"> 
            <h1>Seja bem vindo(a)!</h1>
            <p> Aqui em nossa loja, <i>programadores tem desconto</i> nos produtos para sua casa!</p>
            <br/><br/><br/><br/><br/><br/><br/><br/>
        </div>
    </div>
    );
}
export default Home;